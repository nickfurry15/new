import { Search, SlidersHorizontal, Flame, Clock, Star } from "lucide-react";
import pinProjector from "@/assets/pin-projector.jpg";
import pinHome from "@/assets/pin-home.jpg";
import pinLifestyle from "@/assets/pin-lifestyle.jpg";
import pinCinema from "@/assets/pin-cinema-1.jpg";

const categories = ["All", "Action", "Drama", "Horror", "Sci-Fi", "Romance", "Docs"];

const films = [
  { title: "The Brutalist", genre: "Drama · Epic", rating: "9.0", img: pinProjector, hot: true },
  { title: "Nosferatu", genre: "Horror", rating: "8.2", img: pinHome },
  { title: "A Complete Unknown", genre: "Biography", rating: "8.5", img: pinLifestyle },
  { title: "Nickel Boys", genre: "Drama", rating: "8.8", img: pinCinema, hot: true },
];

const ExploreScreen = () => {
  return (
    <div className="screen">
      <div className="screen-header">
        <h1 className="header-title">Explore</h1>
        <button className="icon-btn"><SlidersHorizontal size={20} /></button>
      </div>

      {/* Search bar */}
      <div className="search-bar">
        <Search size={16} className="search-icon" />
        <input className="search-input" placeholder="Search films, genres, directors…" />
      </div>

      {/* Categories */}
      <div className="chip-scroll">
        {categories.map((cat, i) => (
          <button key={cat} className={`chip ${i === 0 ? "chip-active" : ""}`}>{cat}</button>
        ))}
      </div>

      {/* Trending */}
      <section className="section">
        <div className="section-header">
          <h3 className="section-title"><Flame size={15} className="inline mr-1 text-orange-400" />Trending</h3>
        </div>
        <div className="explore-grid">
          {films.map((film) => (
            <div key={film.title} className="explore-card">
              <div className="explore-img-wrap">
                <img src={film.img} alt={film.title} className="explore-img" />
                {film.hot && <span className="hot-badge">🔥 Hot</span>}
              </div>
              <div className="explore-info">
                <p className="explore-title">{film.title}</p>
                <p className="explore-genre">{film.genre}</p>
                <p className="explore-rating"><Star size={10} className="inline mr-0.5 text-yellow-400" />{film.rating}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Mystery night banner */}
      <section className="section">
        <div className="mystery-banner">
          <div className="mystery-text">
            <span className="mystery-tag">Members Only</span>
            <h3 className="mystery-title">Mystery Night 🎬</h3>
            <p className="mystery-desc">Show up. Don't know what's playing. Trust the vibe.</p>
            <button className="btn-primary mt-3">Join Tonight</button>
          </div>
        </div>
      </section>

      <div className="bottom-spacer" />
    </div>
  );
};

export default ExploreScreen;
