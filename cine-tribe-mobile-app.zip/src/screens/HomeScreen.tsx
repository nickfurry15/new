import heroBg from "@/assets/hero-cinema.jpg";
import pinSquad from "@/assets/pin-squad.jpg";
import pinCozy from "@/assets/pin-cozy.jpg";
import pinPremiere from "@/assets/pin-premiere-2.jpg";
import { Bell, Search, Play, ChevronRight, Star, Clock } from "lucide-react";

const nowPlaying = [
  { title: "Dune: Part Three", genre: "Sci-Fi · Epic", rating: "9.1", time: "2h 48m", bg: "#1a0f2e" },
  { title: "The Substance", genre: "Horror · Drama", rating: "8.4", time: "2h 21m", bg: "#1a0a0a" },
  { title: "Conclave", genre: "Thriller", rating: "8.7", time: "2h 00m", bg: "#0a1a0f" },
];

const HomeScreen = () => {
  return (
    <div className="screen">
      {/* Header */}
      <div className="screen-header">
        <div>
          <p className="header-greeting">Good evening 👋</p>
          <h1 className="header-title">CineTribe</h1>
        </div>
        <div className="header-actions">
          <button className="icon-btn"><Search size={20} /></button>
          <button className="icon-btn notif"><Bell size={20} /><span className="badge" /></button>
        </div>
      </div>

      {/* Hero banner */}
      <div className="hero-banner">
        <img src={heroBg} alt="Cinema" className="hero-img" />
        <div className="hero-overlay" />
        <div className="hero-content">
          <span className="hero-tag">Now Screening</span>
          <h2 className="hero-film-title">Dune: Part Three</h2>
          <p className="hero-meta">IMAX · Dolby Atmos · 2h 48m</p>
          <div className="hero-btns">
            <button className="btn-primary"><Play size={14} className="inline mr-1" />Watch Trailer</button>
            <button className="btn-ghost">Book Seats</button>
          </div>
        </div>
      </div>

      {/* Now Playing */}
      <section className="section">
        <div className="section-header">
          <h3 className="section-title">Now Playing</h3>
          <button className="see-all">See all <ChevronRight size={14} /></button>
        </div>
        <div className="horizontal-scroll">
          {nowPlaying.map((film) => (
            <div key={film.title} className="film-card" style={{ background: film.bg }}>
              <div className="film-card-body">
                <span className="film-genre">{film.genre}</span>
                <h4 className="film-title">{film.title}</h4>
                <div className="film-meta">
                  <span className="film-rating"><Star size={11} className="inline mr-0.5 text-yellow-400" />{film.rating}</span>
                  <span className="film-time"><Clock size={11} className="inline mr-0.5" />{film.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Squad picks */}
      <section className="section">
        <div className="section-header">
          <h3 className="section-title">Squad Picks</h3>
          <button className="see-all">See all <ChevronRight size={14} /></button>
        </div>
        <div className="squad-grid">
          <div className="squad-card large">
            <img src={pinSquad} alt="Squad" className="squad-img" />
            <div className="squad-overlay">
              <p className="squad-label">Your crew loved this</p>
              <p className="squad-title">Watch Party Tonight</p>
            </div>
          </div>
          <div className="squad-col">
            <div className="squad-card small">
              <img src={pinCozy} alt="Cozy" className="squad-img" />
              <div className="squad-overlay">
                <p className="squad-title">Cozy Night In</p>
              </div>
            </div>
            <div className="squad-card small">
              <img src={pinPremiere} alt="Premiere" className="squad-img" />
              <div className="squad-overlay">
                <p className="squad-title">Premiere Access</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="bottom-spacer" />
    </div>
  );
};

export default HomeScreen;
