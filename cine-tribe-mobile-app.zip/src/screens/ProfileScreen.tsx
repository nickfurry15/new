import { Settings, ChevronRight, Film, Users, Star, Crown, Edit3 } from "lucide-react";

const stats = [
  { label: "Films", value: "48" },
  { label: "Reviews", value: "23" },
  { label: "Friends", value: "12" },
];

const menuItems = [
  { icon: Film,    label: "Watch History" },
  { icon: Users,   label: "My Squad" },
  { icon: Star,    label: "Favourite Films" },
  { icon: Crown,   label: "Manage Plan" },
  { icon: Settings,label: "Settings" },
];

const ProfileScreen = () => {
  return (
    <div className="screen">
      <div className="screen-header">
        <h1 className="header-title">Profile</h1>
        <button className="icon-btn"><Settings size={20} /></button>
      </div>

      {/* Avatar + info */}
      <div className="profile-hero">
        <div className="avatar-wrap">
          <div className="avatar">A</div>
          <button className="avatar-edit"><Edit3 size={12} /></button>
        </div>
        <h2 className="profile-name">Alex Martin</h2>
        <p className="profile-email">alex@cinetribe.app</p>
        <div className="plan-badge">⭐ Premium Member</div>
      </div>

      {/* Stats */}
      <div className="profile-stats">
        {stats.map((s) => (
          <div key={s.label} className="profile-stat">
            <p className="pstat-val">{s.value}</p>
            <p className="pstat-lbl">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Menu */}
      <section className="section">
        <div className="menu-list">
          {menuItems.map((item) => (
            <button key={item.label} className="menu-item">
              <div className="menu-icon-wrap"><item.icon size={18} strokeWidth={1.5} /></div>
              <span className="menu-label">{item.label}</span>
              <ChevronRight size={16} className="menu-chevron" />
            </button>
          ))}
        </div>
      </section>

      <div className="bottom-spacer" />
    </div>
  );
};

export default ProfileScreen;
