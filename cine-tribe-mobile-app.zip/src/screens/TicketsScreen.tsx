import { Ticket, Calendar, Clock, MapPin, QrCode } from "lucide-react";

const upcoming = [
  {
    title: "Dune: Part Three",
    date: "Sat 19 Apr",
    time: "20:30",
    cinema: "Pathé Beaugrenelle",
    seat: "F12 · F13",
    type: "IMAX",
    color: "#1a0f2e",
  },
  {
    title: "Conclave",
    date: "Thu 24 Apr",
    time: "19:00",
    cinema: "MK2 Bibliothèque",
    seat: "C8",
    type: "Standard",
    color: "#0a1a0f",
  },
];

const past = [
  { title: "The Brutalist", date: "Sun 6 Apr", cinema: "UGC Ciné Cité Les Halles" },
  { title: "Nosferatu", date: "Fri 28 Mar", cinema: "Pathé Opéra Premier" },
];

const TicketsScreen = () => {
  return (
    <div className="screen">
      <div className="screen-header">
        <h1 className="header-title">My Tickets</h1>
        <button className="icon-btn"><QrCode size={20} /></button>
      </div>

      {/* Upcoming */}
      <section className="section">
        <h3 className="section-title mb-3">Upcoming</h3>
        <div className="tickets-list">
          {upcoming.map((t) => (
            <div key={t.title} className="ticket-card" style={{ borderLeftColor: t.color === "#1a0f2e" ? "#7c3aed" : "#16a34a" }}>
              <div className="ticket-top" style={{ background: t.color }}>
                <div>
                  <span className="ticket-type-badge">{t.type}</span>
                  <h4 className="ticket-title">{t.title}</h4>
                </div>
                <Ticket size={28} className="ticket-icon-large" />
              </div>
              <div className="ticket-bottom">
                <div className="ticket-detail"><Calendar size={13} />{t.date}</div>
                <div className="ticket-detail"><Clock size={13} />{t.time}</div>
                <div className="ticket-detail"><MapPin size={13} />{t.cinema}</div>
                <div className="ticket-seat">Seat {t.seat}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Past */}
      <section className="section">
        <h3 className="section-title mb-3">Past</h3>
        <div className="past-list">
          {past.map((t) => (
            <div key={t.title} className="past-ticket">
              <div>
                <p className="past-title">{t.title}</p>
                <p className="past-meta">{t.date} · {t.cinema}</p>
              </div>
              <span className="past-badge">Attended</span>
            </div>
          ))}
        </div>
      </section>

      <div className="bottom-spacer" />
    </div>
  );
};

export default TicketsScreen;
