import { Gift, Popcorn, Music, MapPin, Star, Crown, Zap } from "lucide-react";

const rewards = [
  { icon: Gift,    points: 500,   title: "Free Screening",  desc: "A ticket on us — any film.",        unlocked: true },
  { icon: Popcorn, points: 800,   title: "Snack Box",       desc: "Delivered to your seat.",           unlocked: true },
  { icon: Music,   points: 1500,  title: "Soundtracks",     desc: "Exclusive vinyl drops.",            unlocked: false },
  { icon: MapPin,  points: 3000,  title: "Set Visit",       desc: "Walk onto a real film set.",        unlocked: false },
  { icon: Star,    points: 5000,  title: "Meet & Greet",    desc: "Face time with a director.",        unlocked: false },
  { icon: Crown,   points: 10000, title: "Premiere VIP",    desc: "Red carpet + after-party.",         unlocked: false },
];

const userPoints = 1240;

const RewardsScreen = () => {
  const pct = Math.min((userPoints / 1500) * 100, 100);

  return (
    <div className="screen">
      <div className="screen-header">
        <h1 className="header-title">Rewards</h1>
        <button className="icon-btn"><Zap size={20} /></button>
      </div>

      {/* Points card */}
      <div className="points-card">
        <p className="points-label">Your Points</p>
        <p className="points-value">{userPoints.toLocaleString()}</p>
        <div className="points-progress-wrap">
          <div className="points-progress-bar">
            <div className="points-progress-fill" style={{ width: `${pct}%` }} />
          </div>
          <p className="points-next">{1500 - userPoints} pts to <strong>Soundtracks</strong></p>
        </div>
        <div className="points-stats">
          <div className="points-stat"><p className="stat-val">12</p><p className="stat-lbl">Films seen</p></div>
          <div className="points-stat"><p className="stat-val">2×</p><p className="stat-lbl">Multiplier</p></div>
          <div className="points-stat"><p className="stat-val">Premium</p><p className="stat-lbl">Plan</p></div>
        </div>
      </div>

      {/* Rewards grid */}
      <section className="section">
        <h3 className="section-title mb-3">Redeem</h3>
        <div className="rewards-grid">
          {rewards.map((r) => (
            <div key={r.title} className={`reward-card ${r.unlocked ? "reward-unlocked" : "reward-locked"}`}>
              <div className="reward-icon-wrap">
                <r.icon size={20} strokeWidth={1.5} />
              </div>
              <p className="reward-pts">{r.points.toLocaleString()} pts</p>
              <h4 className="reward-title">{r.title}</h4>
              <p className="reward-desc">{r.desc}</p>
              {r.unlocked
                ? <button className="btn-primary w-full mt-3 text-xs py-1.5">Redeem</button>
                : <div className="reward-lock">🔒 {r.points - userPoints} pts away</div>
              }
            </div>
          ))}
        </div>
      </section>

      <div className="bottom-spacer" />
    </div>
  );
};

export default RewardsScreen;
