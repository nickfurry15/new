import { Menu, X, Film, Ticket, Users, Gift } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const links = [
  { label: "Plans", icon: Ticket },
  { label: "Features", icon: Film },
  { label: "Experiences", icon: Users },
  { label: "Rewards", icon: Gift },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-8">
        <div className="flex items-center justify-between h-14">
          <span className="text-2xl font-serif-display font-bold italic text-foreground tracking-tight">BGC</span>

          <div className="hidden md:flex items-center gap-7">
            {links.map((l) => (
              <a
                key={l.label}
                href={`#${l.label.toLowerCase()}`}
                className="flex items-center gap-1.5 text-[11px] font-medium tracking-[0.12em] uppercase text-muted-foreground hover:text-foreground transition-colors"
              >
                <l.icon className="w-3.5 h-3.5" strokeWidth={1.5} />
                {l.label}
              </a>
            ))}
          </div>

          <div className="hidden md:block">
            <Button size="sm" className="bg-primary text-primary-foreground rounded-full text-[11px] px-5 h-8 hover:bg-primary/90 font-medium">
              Join BGC
            </Button>
          </div>

          <button onClick={() => setOpen(!open)} className="md:hidden text-foreground">
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {open && (
          <div className="md:hidden pb-5 space-y-3 border-t border-border pt-4">
            {links.map((l) => (
              <a key={l.label} href={`#${l.label.toLowerCase()}`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground py-1" onClick={() => setOpen(false)}>
                <l.icon className="w-4 h-4" strokeWidth={1.5} />
                {l.label}
              </a>
            ))}
            <Button className="w-full bg-primary text-primary-foreground rounded-full text-xs">Join BGC</Button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
