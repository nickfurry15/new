import pinHome from "@/assets/pin-home.jpg";
import pinProjector from "@/assets/pin-projector.jpg";
import pinLifestyle from "@/assets/pin-lifestyle.jpg";
import { Users, Sparkles, Eye, Heart, Film, Monitor } from "lucide-react";

const features = [
  { icon: Users, title: "Squad Mode", desc: "Create groups, vote on films, and book seats together. Cinema is better with your people." },
  { icon: Sparkles, title: "Smart Picks", desc: "Recommendations that get you. Based on mood, taste, and what your friends loved." },
  { icon: Eye, title: "Mystery Night", desc: "Show up. Don't know what's playing. Trust the vibe. Our members' favorite feature." },
  { icon: Heart, title: "Cinema Dates", desc: "Couple seats, dinner combos, and curated romantic picks for the perfect night out." },
  { icon: Film, title: "Behind the Scenes", desc: "Director's cuts, deleted scenes, and exclusive making-of documentaries." },
  { icon: Monitor, title: "Stream or Screen", desc: "Same membership works at home and at the theater. Your choice, always." },
];

const Features = () => {
  return (
    <section id="features" className="py-20 px-4 sm:px-8 bg-card/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-14">
          <span className="section-label">Features</span>
          <h2 className="section-heading mt-3">More than<br />a ticket</h2>
        </div>

        {/* Pinterest masonry */}
        <div className="columns-2 lg:columns-3 gap-3.5 space-y-3.5">
          {/* Tall image pin */}
          <div className="pin-card break-inside-avoid">
            <img src={pinProjector} alt="Film projector" className="w-full aspect-[3/4] object-cover" loading="lazy" width={640} height={960} />
            <div className="p-4">
              <p className="text-sm font-serif-display font-semibold italic text-foreground">The magic of 35mm</p>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">Some things are just better on the big screen.</p>
            </div>
          </div>

          {/* Feature cards */}
          {features.slice(0, 2).map((f) => (
            <div key={f.title} className="pin-card break-inside-avoid p-5">
              <f.icon className="w-5 h-5 text-primary mb-3" strokeWidth={1.5} />
              <h3 className="text-lg font-serif-display font-semibold italic text-foreground mb-1.5">{f.title}</h3>
              <p className="text-[13px] text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}

          {/* Square image pin */}
          <div className="pin-card break-inside-avoid">
            <img src={pinLifestyle} alt="Cinema aesthetic" className="w-full aspect-square object-cover" loading="lazy" width={800} height={1000} />
            <div className="p-4">
              <p className="text-sm font-serif-display font-semibold italic text-foreground">Vintage vibes</p>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">Tickets, reels, and popcorn — the classics never get old.</p>
            </div>
          </div>

          {features.slice(2, 4).map((f) => (
            <div key={f.title} className="pin-card break-inside-avoid p-5">
              <f.icon className="w-5 h-5 text-primary mb-3" strokeWidth={1.5} />
              <h3 className="text-lg font-serif-display font-semibold italic text-foreground mb-1.5">{f.title}</h3>
              <p className="text-[13px] text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}

          {/* Home cinema pin */}
          <div className="pin-card break-inside-avoid">
            <img src={pinHome} alt="Home cinema" className="w-full aspect-[4/5] object-cover" loading="lazy" width={640} height={640} />
            <div className="p-4">
              <p className="text-sm font-serif-display font-semibold italic text-foreground">Stream from home</p>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">Blankets, fairy lights, your favorite film. Same membership.</p>
            </div>
          </div>

          {features.slice(4).map((f) => (
            <div key={f.title} className="pin-card break-inside-avoid p-5">
              <f.icon className="w-5 h-5 text-primary mb-3" strokeWidth={1.5} />
              <h3 className="text-lg font-serif-display font-semibold italic text-foreground mb-1.5">{f.title}</h3>
              <p className="text-[13px] text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
