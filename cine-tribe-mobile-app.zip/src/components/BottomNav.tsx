import { Home, Compass, Ticket, Gift, User } from "lucide-react";

const tabs = [
  { id: "home",    icon: Home,    label: "Home" },
  { id: "explore", icon: Compass, label: "Explore" },
  { id: "tickets", icon: Ticket,  label: "Tickets" },
  { id: "rewards", icon: Gift,    label: "Rewards" },
  { id: "profile", icon: User,    label: "Profile" },
];

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const BottomNav = ({ activeTab, setActiveTab }: BottomNavProps) => {
  return (
    <nav className="bottom-nav">
      {tabs.map(({ id, icon: Icon, label }) => (
        <button
          key={id}
          onClick={() => setActiveTab(id)}
          className={`nav-tab ${activeTab === id ? "active" : ""}`}
        >
          <Icon className="nav-icon" strokeWidth={activeTab === id ? 2.2 : 1.6} />
          <span className="nav-label">{label}</span>
        </button>
      ))}
    </nav>
  );
};

export default BottomNav;
