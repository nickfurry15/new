import heroBg from "@/assets/hero-cinema.jpg";
import pinSquad from "@/assets/pin-squad.jpg";
import pinLifestyle from "@/assets/pin-lifestyle.jpg";
import pinCozy from "@/assets/pin-cozy.jpg";
import { Button } from "@/components/ui/button";
import { ArrowRight, Play } from "lucide-react";

const Hero = () => {
  return (
    <section className="pt-20 pb-6 px-4 sm:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Big BGC title */}
        <div className="text-center pt-8 pb-10">
          <h1 className="text-8xl sm:text-9xl md:text-[12rem] font-serif-display font-bold italic text-foreground leading-none tracking-tight">
            BGC
          </h1>
          <p className="text-sm text-muted-foreground mt-4 max-w-sm mx-auto leading-relaxed font-light">
            Your cinema membership. Watch, share, and experience movies like never before.
          </p>
          <div className="flex items-center justify-center gap-3 mt-6">
            <Button className="bg-primary text-primary-foreground rounded-full text-xs px-6 h-10 hover:bg-primary/90 font-medium">
              Explore plans <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Button>
            <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground text-xs font-medium transition-colors">
              <span className="w-10 h-10 rounded-full border border-border flex items-center justify-center">
                <Play className="w-3.5 h-3.5 ml-0.5" />
              </span>
              Watch reel
            </button>
          </div>
        </div>

        {/* Cinema image */}
        <div className="relative rounded-[2rem] overflow-hidden mb-4" style={{ aspectRatio: "16/9" }}>
          <img src={heroBg} alt="Luxurious cinema interior" className="w-full h-full object-cover" width={1920} height={1080} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-8">
            <p className="text-white/90 text-sm sm:text-base font-medium">The ultimate cinema experience</p>
            <p className="text-white/50 text-xs mt-1">IMAX · Dolby Atmos · Private screenings</p>
          </div>
        </div>

        {/* Three-column pin grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="pin-card">
            <img src={pinSquad} alt="Friends at cinema" className="w-full aspect-[3/4] object-cover" loading="lazy" width={800} height={600} />
            <div className="p-3.5">
              <p className="text-[10px] text-muted-foreground tracking-wider uppercase">Squad</p>
              <p className="text-xs font-medium text-foreground mt-0.5 leading-snug">Go with your crew, every&nbsp;time.</p>
            </div>
          </div>
          <div className="pin-card">
            <img src={pinLifestyle} alt="Cinema lifestyle" className="w-full aspect-[3/4] object-cover" loading="lazy" width={800} height={1000} />
            <div className="p-3.5">
              <p className="text-[10px] text-muted-foreground tracking-wider uppercase">Perks</p>
              <p className="text-xs font-medium text-foreground mt-0.5 leading-snug">Snacks, merch & surprise&nbsp;tickets.</p>
            </div>
          </div>
          <div className="pin-card">
            <img src={pinCozy} alt="Cozy home cinema" className="w-full aspect-[3/4] object-cover" loading="lazy" width={800} height={1000} />
            <div className="p-3.5">
              <p className="text-[10px] text-muted-foreground tracking-wider uppercase">Stream</p>
              <p className="text-xs font-medium text-foreground mt-0.5 leading-snug">Same membership, from your&nbsp;couch.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
