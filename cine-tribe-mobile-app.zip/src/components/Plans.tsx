import { Check, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

const plans = [
  {
    name: "Classic",
    price: "9.99",
    note: "For the casual movie lover",
    accent: "bg-secondary",
    features: [
      "5 theater visits / month",
      "Standard streaming library",
      "Personalized recommendations",
      "Groups up to 5 friends",
      "1× loyalty points",
      "Free popcorn monthly",
    ],
  },
  {
    name: "Premium",
    price: "19.99",
    note: "Our most popular pick",
    popular: true,
    accent: "bg-primary",
    features: [
      "12 visits / month",
      "Full HD streaming",
      "IMAX & Dolby access",
      "Unlimited watch parties",
      "2× loyalty points",
      "Priority seating",
      "Surprise screenings",
      "1 guest pass / month",
    ],
  },
  {
    name: "Gold",
    price: "34.99",
    note: "For the truly obsessed",
    gold: true,
    accent: "golden-badge",
    features: [
      "Unlimited visits",
      "4K streaming + offline",
      "Private screening rooms",
      "3× loyalty points",
      "VIP lounge & snacks",
      "Premiere invites",
      "Set visit lottery",
      "Director's cut early access",
    ],
  },
];

const Plans = () => {
  return (
    <section id="plans" className="py-20 px-4 sm:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-14">
          <span className="section-label">Membership</span>
          <h2 className="section-heading mt-3">Find your plan</h2>
          <p className="text-sm text-muted-foreground mt-4 max-w-md mx-auto leading-relaxed">
            Three tiers, one goal — make every movie night unforgettable.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto items-start">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`pin-card p-6 pt-8 flex flex-col relative ${
                plan.popular ? "ring-1 ring-primary/20 md:-mt-3 md:mb-[-12px]" : ""
              } ${plan.gold ? "ring-1 ring-[hsl(38,70%,55%)]/20" : ""}`}
            >
              {plan.popular && (
                <span className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold tracking-wider uppercase whitespace-nowrap mt-[20px]">
                  Most popular
                </span>
              )}
              {plan.gold && (
                <span className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-3 py-1 rounded-full golden-badge text-[10px] font-semibold tracking-wider uppercase whitespace-nowrap flex items-center gap-1 mt-[20px]">
                  <Star className="w-3 h-3" /> Gold
                </span>
              )}

              <h3 className="text-3xl sm:text-4xl font-serif-display font-bold italic text-foreground">{plan.name}</h3>
              <p className="text-xs text-muted-foreground mt-1.5 mb-5">{plan.note}</p>

              <div className="mb-6">
                <span className="text-5xl font-serif-display font-bold text-foreground">€{plan.price}</span>
                <span className="text-xs text-muted-foreground ml-1">/mo</span>
              </div>

              <ul className="space-y-2.5 mb-7 flex-1">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-[13px] text-foreground/80">
                    <Check className={`w-3.5 h-3.5 mt-0.5 flex-shrink-0 ${plan.gold ? "text-[hsl(38,70%,55%)]" : "text-primary"}`} />
                    {f}
                  </li>
                ))}
              </ul>

              <Button
                className={`w-full rounded-full text-xs h-10 font-medium ${
                  plan.popular
                    ? "bg-primary text-primary-foreground hover:bg-primary/90"
                    : plan.gold
                    ? "golden-badge hover:opacity-90 border-0"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                Get {plan.name}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Plans;
