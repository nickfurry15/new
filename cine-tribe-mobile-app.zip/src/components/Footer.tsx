const Footer = () => {
  return (
    <footer className="py-12 px-4 sm:px-8 border-t border-border/50">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="text-2xl font-serif-display font-bold italic text-foreground tracking-tight">BGC</span>
          <p className="text-[11px] text-muted-foreground/50">
            © 2026 BGC · All rights reserved
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
