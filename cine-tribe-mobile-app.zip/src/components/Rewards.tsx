import { Gift, Popcorn, Music, MapPin, Star, Crown } from "lucide-react";

const rewards = [
  { icon: Gift, points: "500", title: "Free Screening", desc: "A ticket on us — any film, any time." },
  { icon: Popcorn, points: "800", title: "Snack Box", desc: "Popcorn, drinks, and candy. Delivered to your seat." },
  { icon: Music, points: "1.5K", title: "Soundtracks", desc: "Exclusive film playlists and vinyl drops." },
  { icon: MapPin, points: "3K", title: "Set Visit", desc: "Walk onto a real film set with the crew." },
  { icon: Star, points: "5K", title: "Meet & Greet", desc: "Face time with a director or actor." },
  { icon: Crown, points: "10K", title: "Premiere VIP", desc: "Red carpet, front row, and the after-party." },
];

const Rewards = () => {
  return (
    <section id="rewards" className="py-20 px-4 sm:px-8 bg-card/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-14">
          <span className="section-label">Rewards</span>
          <h2 className="section-heading mt-3">Points that<br />actually count</h2>
          <p className="text-sm text-muted-foreground mt-4 max-w-md mx-auto leading-relaxed">
            Every visit and stream earns points. Redeem them for things you'll actually want.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-w-3xl mx-auto">
          {rewards.map((r, i) => (
            <div key={r.title} className="pin-card p-5 text-center group">
              <div className="w-10 h-10 rounded-xl bg-secondary mx-auto mb-3 flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                <r.icon className="w-4.5 h-4.5 text-primary" strokeWidth={1.5} />
              </div>
              <span className="text-[11px] font-semibold text-primary tracking-wider block mb-1.5">
                {r.points} pts
              </span>
              <h3 className="text-base font-serif-display font-semibold italic text-foreground mb-1">{r.title}</h3>
              <p className="text-[12px] text-muted-foreground leading-relaxed">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Rewards;
