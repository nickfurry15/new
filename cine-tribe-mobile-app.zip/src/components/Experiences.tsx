import pinPremiere from "@/assets/pin-premiere-2.jpg";
import pinSquad from "@/assets/pin-squad.jpg";
import { Ticket, Dice5, Users2, Clapperboard } from "lucide-react";

const experiences = [
  {
    icon: Ticket,
    title: "Surprise Screenings",
    desc: "A secret film, a packed room, zero spoilers. Our members' all-time favorite.",
    label: "Fan favorite",
  },
  {
    icon: Dice5,
    title: "Set Visit Lottery",
    desc: "Gold members enter a monthly draw to visit a real film set. Yes, really.",
    label: "Gold exclusive",
  },
  {
    icon: Users2,
    title: "Watch Parties",
    desc: "Sync up with friends — in theater or virtual. Live reactions, shared snacks.",
    label: "All plans",
  },
  {
    icon: Clapperboard,
    title: "Premiere Nights",
    desc: "Red carpet access, Q&A with directors, and the after-party. Be there first.",
    label: "Premium & Gold",
  },
];

const Experiences = () => {
  return (
    <section id="experiences" className="py-20 px-4 sm:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-14">
          <span className="section-label">Experiences</span>
          <h2 className="section-heading mt-3">Unforgettable<br />nights</h2>
          <p className="text-sm text-muted-foreground mt-4 max-w-sm mx-auto leading-relaxed">
            Beyond the screen — moments you'll actually remember.
          </p>
        </div>

        {/* Editorial two-image hero */}
        <div className="grid grid-cols-5 gap-3 mb-4 max-w-4xl mx-auto">
          <div className="col-span-3 pin-card overflow-hidden">
            <div className="relative">
              <img src={pinPremiere} alt="Premiere night" className="w-full aspect-[4/3] object-cover" loading="lazy" width={1200} height={600} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 p-5">
                <span className="text-[9px] font-semibold tracking-[0.2em] uppercase text-white/50">Exclusive</span>
                <p className="text-base sm:text-lg font-serif-display font-semibold italic text-white mt-1 leading-snug">
                  Walk the red carpet<br />before anyone else.
                </p>
              </div>
            </div>
          </div>
          <div className="col-span-2 pin-card overflow-hidden">
            <div className="relative">
              <img src={pinSquad} alt="Friends laughing" className="w-full aspect-[4/3] object-cover" loading="lazy" width={800} height={600} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 p-4">
                <span className="text-[9px] font-semibold tracking-[0.2em] uppercase text-white/50">Together</span>
                <p className="text-sm font-serif-display font-semibold italic text-white mt-1 leading-snug">
                  Better with friends.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Experience cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-4xl mx-auto">
          {experiences.map((exp) => (
            <div key={exp.title} className="pin-card p-4 flex flex-col">
              <div className="w-9 h-9 rounded-xl bg-secondary flex items-center justify-center mb-3">
                <exp.icon className="w-4 h-4 text-primary" strokeWidth={1.5} />
              </div>
              <span className="text-[9px] font-semibold tracking-[0.2em] uppercase text-primary/60 mb-1.5">
                {exp.label}
              </span>
              <h3 className="text-base font-serif-display font-semibold italic text-foreground mb-1">{exp.title}</h3>
              <p className="text-[12px] text-muted-foreground leading-relaxed flex-1">{exp.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experiences;
