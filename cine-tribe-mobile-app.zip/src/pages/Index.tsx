import { useState } from "react";
import HomeScreen from "@/screens/HomeScreen";
import ExploreScreen from "@/screens/ExploreScreen";
import TicketsScreen from "@/screens/TicketsScreen";
import RewardsScreen from "@/screens/RewardsScreen";
import ProfileScreen from "@/screens/ProfileScreen";
import BottomNav from "@/components/BottomNav";

const Index = () => {
  const [activeTab, setActiveTab] = useState("home");

  const renderScreen = () => {
    switch (activeTab) {
      case "home":     return <HomeScreen />;
      case "explore":  return <ExploreScreen />;
      case "tickets":  return <TicketsScreen />;
      case "rewards":  return <RewardsScreen />;
      case "profile":  return <ProfileScreen />;
      default:         return <HomeScreen />;
    }
  };

  return (
    <div className="app-shell">
      <div className="screen-content">
        {renderScreen()}
      </div>
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

export default Index;
